1.Install a Mysql Workbench using Mysql Installer.

2.Create a database
    Create database schoolmngsystem;

3.Create a table
    create table studentdetails(
        fname varchar(255) not null,
        lname varchar(255) not null ,
        dob date not null,
        pname varchar(255) not null,
        address varchar(255) not null,
        city varchar(255) not null,
        pnumber varchar(255) not null,
        grade int not null default 1,
        science int not null default 1,
        sst int not null default 1,
        math int not null default 1,
        english int not null default 1,
        hindi int not null default 1,
        percentage int not null default 1
    )

4.Connect database as shown in 'database.js' file.

5.Finally run the app.js

6.Your app is live at the port 3000;
