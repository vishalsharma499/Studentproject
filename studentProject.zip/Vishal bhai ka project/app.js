const mysql = require('mysql');
const express = require('express');
const app = express();

const kill = require("kill-port");

const ejs = require('ejs');
app.set('view engine','ejs');

const router = express.Router();
const conn = require('./database');



var bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({extended:true}));



app.get("/",(req,res)=>{
    res.sendFile(__dirname+"/index.html");
});

app.post("/",(req,res)=>{

    console.log(req.body);
    var fname = req.body.fname;
    var lname = req.body.lname;
    var dob1st = req.body.dob;
    var dob = dob1st.split("/").reverse().join("-");
    var pname = req.body.pname;
    var address = req.body.address;
    var city = req.body.city;
    var pnumber = req.body.pnumber;
    var grade = Number.parseInt(req.body.grade);
    var science = Number.parseInt(req.body.science);
    var sst = Number.parseInt(req.body.sst);
    var math = Number.parseInt(req.body.math);
    var english= Number.parseInt(req.body.english);
    var hindi = Number.parseInt(req.body.hindi);
    var percentage = Number.parseInt(req.body.percentage);

    const sql = `Insert into studentdetails values ('${fname}','${lname}','${dob}','${pname}','${address}','${city}','${pnumber}','${grade}','${science}','${sst}','${math}','${english}','${hindi}',${percentage})`;

    conn.query(sql, function (error, results, fields) {
        if (error) throw error;
        // connected!

        console.log(results);
        // conn.end();
    });
    // kill(3000, "tcp");
    res.sendFile(__dirname+"/index.html");
});

app.post('/show_data',(req,res)=>{

    const query ="Select * from studentdetails where percentage>59";

    conn.query(query,function(error,data,action){
        if(error){
            throw error;
        }
        else{
            
            res.render('sample_data', {title:'Student Details',action:'list',sampleData:data});
            // console.log(data);
        }
    })
});

app.listen(3000,()=>{
    console.log("Server is live");
});







