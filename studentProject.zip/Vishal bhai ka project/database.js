const mysql = require('mysql');

const connection = mysql.createConnection({   //Creating the MYSQL connection.
    host: "localhost",
    user: "root",
    password: "mypassword",
    database: 'schoolmngsystem'

    /*
    alter user 'root'@'localhost' identified with mysql_native_password by 'mypassword';

        to handle the client does not support and else errors, execute the above line into the database.
    */
});
connection.connect(function (err) {
    if (err)
        throw err;
    console.log("Connection Successful......");
});

module.exports = connection;